package com.capgemini.merchantstore.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.capgemini.merchantstore.beans.Product;

public interface IProductRepo extends JpaRepository<Product, Integer>, CrudRepository<Product, Integer>{

}
