package com.capgemini.merchantstore.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.merchantstore.beans.Merchant;
import com.capgemini.merchantstore.beans.Product;
import com.capgemini.merchantstore.exceptions.MerchantNotFoundException;
import com.capgemini.merchantstore.services.IMerchantService;

@Controller
public class MerchantController {
	
	@Autowired
	IMerchantService MerchantServices;
	
	@RequestMapping(value = "merchantSignIn")
	public ModelAndView addMerchant(@ModelAttribute("merchant") Merchant merchant, @RequestParam("securityQuestion") String question, @RequestParam("type") String type) {
		System.out.println(type);
		merchant.setSecurityQuestion(question);
		merchant = MerchantServices.addMerchant(merchant);
		return new ModelAndView("indexPage");
	}
	
	@RequestMapping(value = "addProductSuccessPage")
	public ModelAndView addProduct(@ModelAttribute("product") Product product,@RequestParam("abc")int merchantId) {
		product = MerchantServices.addProduct(product);
		System.out.println(merchantId);
		return new ModelAndView("addProductSuccessPage");
	}
	
	@RequestMapping(value = "removedProduct")
	public ModelAndView removeProduct(@ModelAttribute("product") Product product) {
		//Product product = new Product();
		MerchantServices.removeProduct(product);
		return new ModelAndView("removeProductSuccess","product", product);
	}
	
	@RequestMapping(value = "updateSuccess")
	public ModelAndView updateProduct(@RequestParam("productId") int productId) {
		Product product = new Product();
		product = MerchantServices.getProductDetails(productId);
		return new ModelAndView("addProduct", "product",product);
	}
	
	@RequestMapping(value = "getAllProducts")
	public ModelAndView addAllProduct() {
		List<Product> product = MerchantServices.getAllProducts();
	
		return new ModelAndView("getAllProducts", "product", product);
	}
	@RequestMapping(value = "forgotpassword")
	public ModelAndView forgotPassword(@RequestParam("username") String username) {
		Merchant merchant = null;
		
		try {
			merchant = MerchantServices.getMerchant(username);
			
			
		} catch (MerchantNotFoundException e) {
			new ModelAndView("errorPage","error",e.getMessage());
			e.printStackTrace();
		}
		return new ModelAndView("securityQuestion","merchant",merchant);
	}
	@RequestMapping(value = "Answer/{email:.+}")
	public ModelAndView securityAnswer(@PathVariable String email, @RequestParam("answer") String answer) {
		Merchant merchant = null;
		try {
			
			merchant = MerchantServices.getMerchant(email);
			System.out.println("\n\n\n\n" + merchant);
			if(merchant.getSecurityAnswer().compareTo(answer) != 0) {
				String message = "Not a valid user";
				return new ModelAndView("InvalidUserPage","message",message);
			}
		} catch (MerchantNotFoundException e) {
			new ModelAndView("errorPage","error",e.getMessage());
			e.printStackTrace();
		
		}
		return new ModelAndView("securityAnswer","message",merchant.getPassword());
	}
	
	@RequestMapping(value="changePassword1")
	public ModelAndView changePassword(@RequestParam("merchantId") int merchantId) {
		return new ModelAndView("changePassword","merchantId",merchantId);
	}

	@RequestMapping(value="changePasswordSuccess1/{merchantId}")
	public ModelAndView changePasswordSuccess(@PathVariable int merchantId, @RequestParam("oldPassword")String oldPassword,@RequestParam("newPassword")String newPassword,@RequestParam("confirmNewPassword")String confirmNewPassword ) {
		Merchant merchant = MerchantServices.findMerchantId(merchantId);
		MerchantServices.changePassword(merchant, newPassword);
		System.out.println(merchant.getPassword());
		return new ModelAndView("changePasswordSuccess");
	}
	
	@RequestMapping(value="myProfilesuccess")
	public ModelAndView myProfile(@RequestParam("merchantId") int merchantId ) {
		Merchant merchant = MerchantServices.findMerchantId(merchantId);
		return new ModelAndView("myProfilesuccess", "merchant", merchant);
	}

}
