package com.capgemini.merchantstore.services;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.external.biz.base64Coder.Base64Coder;

import com.capgemini.merchantstore.beans.Merchant;
import com.capgemini.merchantstore.beans.Product;
import com.capgemini.merchantstore.exceptions.MerchantNotFoundException;
import com.capgemini.merchantstore.repo.IMerchantRepo;
import com.capgemini.merchantstore.repo.IProductRepo;

import cucumber.deps.com.thoughtworks.xstream.core.util.Base64Encoder;
@Component("MerchantServices")
public class MerchantServiceImpl implements IMerchantService {

	@Autowired(required = true)
	IMerchantRepo repo;
	
	@Autowired(required= true)
	IProductRepo prepo;

	@Override
	public Merchant addMerchant(Merchant merchant) {
		merchant.setAddMerchantDate(new Date());
		String pwd = Base64Coder.encodeString(merchant.getPassword());
		merchant.setPassword(pwd);
		return repo.save(merchant);
	}

	@Override
	public Product addProduct(Product product) {
		
		return prepo.save(product);
	}

	@Override
	public List<Product> getAllProducts() {
		
		return prepo.findAll();
	}

	@Override
	public void updateProduct(Product product) {
	
		prepo.save(product);
	}

	@Override
	public Product getProductDetails(int productId) {
		
		return prepo.getOne(productId);
	}

	@Override
	public void removeProduct(Product product) {
		prepo.delete(product);
		
	}

	@Override
	public Merchant getMerchant(String username) throws MerchantNotFoundException {
		if(repo.findByUsername(username) == null) {
			throw new MerchantNotFoundException("No Merchant Found");
		}
		 Merchant merchant = repo.findByUsername(username);
		 merchant.setPassword(Base64Coder.decodeString(merchant.getPassword()));
		 return merchant;
	}

	@Override
	public Merchant updateMerchant(Merchant merchant) {
		
		return repo.save(merchant);
	}

	@Override
	public Merchant deleteMerchant(String username) {
		
		Merchant merchant = repo.findByUsername(username);
		repo.deleteById(merchant.getMerchantId());
		return merchant;
	
	}
	
	@Override
	public void changePassword(Merchant merchant,String password) {
		
		merchant.setPassword(Base64Coder.encodeString(password));
		repo.save(merchant);
	}

	@Override
	public Merchant findMerchantId(int id) {
		Merchant merchant = repo.getOne(id);
		return merchant;
	}



}
