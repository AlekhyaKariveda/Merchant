package com.capgemini.merchantstore.services;

import java.util.List;

import com.capgemini.merchantstore.beans.Merchant;
import com.capgemini.merchantstore.beans.Product;
import com.capgemini.merchantstore.exceptions.MerchantNotFoundException;

public interface IMerchantService {
	public Merchant addMerchant(Merchant merchant);
	public Merchant updateMerchant(Merchant merchant);
	public Merchant deleteMerchant(String username);
	public Product addProduct(Product product);
	public List<Product> getAllProducts();
	public void updateProduct(Product product);
	public Product getProductDetails(int productId);
	public void removeProduct(Product product);
	public Merchant getMerchant(String username) throws MerchantNotFoundException;
	public void changePassword(Merchant merchant,String password);
	public Merchant findMerchantId(int id);
}
